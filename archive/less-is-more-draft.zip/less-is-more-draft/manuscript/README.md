# Blank Research Paper Template

This is a reusable LaTeX research-paper template with a clean Springer
Nature-inspired manuscript style. It supports either a single-column body or
a two-column body while keeping the title, authors, affiliations, abstract,
highlights, and keywords full width. It also includes Source Sans 3 typography, Geist
Mono for code, Fira Math for equations, balanced
layout-specific margins, numeric references, ORCID support, review line
numbers, theorem environments, polished floats and code listings, modular
sections, declarations, and appendices.

The shared layout is intentionally publisher-neutral. For an actual
submission, replace the `article` class with the exact class and instructions
supplied by the target journal (for example, `sn-jnl`). Springer Nature also
advises authors to check the selected journal's own submission instructions.
The official Springer Nature package currently asks authors to submit one
consolidated `.tex` manuscript rather than a set of `\input` files, so flatten
the modular sources when preparing the final upload.

## Choose one or two columns

Near the top of `manuscript.tex`, select the package options:

```tex
\usepackage[twocolumn,final,nobibliography]{template}
```

Change only `twocolumn` to `onecolumn` for a single-column body:

```tex
\usepackage[onecolumn,final,nobibliography]{template}
```

In two-column mode, the split begins immediately after the abstract and
keywords on the same page. Use `figure*` and `table*` for material that must
span both columns. `longtable` is intended for single-column mode because it
cannot span the two-column page layout.

## Start a new paper

1. Edit `metadata.tex` (title, authors, ORCIDs, affiliations, correspondence,
   and keywords).
2. Edit the abstract, highlights, and section order in `manuscript.tex`.
3. Replace the section placeholders.
4. Add figures to `figures/` and citations to `bibliography.bib`.
5. Change the `nobibliography` package option to `bibliography` after adding
   citations.
6. Add or remove acronym definitions in `abbreviations.tex`.
7. Copy reusable snippets from `examples/components.tex` as needed.
8. Complete the applicable statements in `sections/declarations.tex`.

## File organization

- `manuscript.tex` contains the front matter and document outline.
- `metadata.tex` contains paper-specific title and author information.
- `abbreviations.tex` contains acronym definitions.
- `template.sty` contains packages, fonts, page geometry, environments, and
  typography. It normally does not need editing for a new paper.
- `sections/` contains the manuscript body in modular files.

The original paper's bibliography is retained in
`resources/original-references.bib` for optional reuse. Copy only the entries
you need into `bibliography.bib` to keep each new paper clean.

## Build

The template uses bundled OpenType/TrueType fonts and therefore compiles with
LuaLaTeX. For the untouched blank template, run:

```text
lualatex manuscript.tex
lualatex manuscript.tex
```

After adding citations and selecting the `bibliography` package option, run:

```text
lualatex manuscript.tex
biber manuscript
lualatex manuscript.tex
lualatex manuscript.tex
```

Alternatively, after MiKTeX/TeX Live setup is complete, `latexmk` can manage
the required passes automatically:

```text
latexmk -lualatex -use-biber manuscript.tex
```

## Optional settings

- Change the `final` package option to `review` to enable line numbering and
  one-and-a-half line spacing.
- Uncomment `\makeglossaries` and add a printed glossary command if the target
  journal requires an acronym list.
- Replace the `nejm` bibliography style if a journal supplies its own style.

## Font naming convention

Font directories and files use lowercase kebab-case for consistent behavior
across Windows, macOS, Linux, Git, and Overleaf:

- `fonts/source-sans/source-sans-<weight>-<style>.ttf`
- `fonts/fira-math/fira-math-regular.otf`
- `fonts/geist-mono/geist-mono-<weight>-<style>.ttf`

The main template uses Source Sans 3 for body and heading text, Geist Mono for
listings and other monospaced text, and Fira Math for mathematical notation.
When migrating to an official publisher class, follow that class's font rules.

## Included resources

- Full Source Sans 3 font family
- Fira Math font
- Full Geist Mono font family
- Clean `bibliography.bib`
- Original reference library under `resources/`
- Blank modular sections and appendices
- A structured declarations section
- Examples for figures, tables, equations, algorithms, listings, citations,
  cross-references, proofs, and two-column-spanning floats
